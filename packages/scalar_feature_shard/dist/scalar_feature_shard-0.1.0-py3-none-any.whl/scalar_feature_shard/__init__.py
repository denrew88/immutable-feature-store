"""Public facade for dense-long scalar feature shards."""

from .builder import ScalarBuildSessionStatus, ScalarDatasetBuilder
from .dense_long import (
    ScalarDenseLongDataset,
    build_dense_long_shards_from_sample_major_manifest,
    open_dense_long_shard,
)
from .exceptions import (
    FeatureNotFoundError,
    ManifestFormatError,
    SampleNotFoundError,
    ScalarFeatureShardError,
)
from .metadata import write_feature_meta, write_sample_meta
from .models import (
    BuildOptions,
    FeatureValues,
    QueryResult,
    ScalarValue,
    SelectionCandidate,
    SelectionOptions,
    SelectionResult,
)
from .selection import run_selection, select_features
from .writer import build_shard

__all__ = [
    "BuildOptions",
    "FeatureNotFoundError",
    "FeatureValues",
    "ManifestFormatError",
    "QueryResult",
    "SampleNotFoundError",
    "ScalarDatasetBuilder",
    "ScalarFeatureShardError",
    "ScalarBuildSessionStatus",
    "ScalarDenseLongDataset",
    "ScalarValue",
    "SelectionCandidate",
    "SelectionOptions",
    "SelectionResult",
    "build_dense_long_shards_from_sample_major_manifest",
    "build_shard",
    "open_dense_long_shard",
    "run_selection",
    "select_features",
    "write_feature_meta",
    "write_sample_meta",
]
