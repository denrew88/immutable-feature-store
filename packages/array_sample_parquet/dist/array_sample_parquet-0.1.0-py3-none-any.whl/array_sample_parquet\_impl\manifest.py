"""Manifest models for array_sample_parquet v1."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

from ..types import PointColumnSpec
from .support import _normalize_point_schema


FORMAT_NAME = "array-sample-parquet"
FORMAT_VERSION = 1
DEFAULT_SAMPLE_KEY_COL = "sample_key"
DEFAULT_FEATURE_KEY_COL = "feature_key"


@dataclass
class ArraySampleParquetBuildOptions:
    """array_sample_parquet build 옵션.

    builder는 sample별 raw parquet를 먼저 commit하고 compact 단계에서 final part를
    만듭니다. part 경계는 sample 수가 아니라 추정 payload byte와 row 수를 우선해서
    결정합니다. `max_part_samples`는 필요할 때만 거는 안전 제한입니다.
    """

    # final part 하나의 목표 크기(byte). 처음에는 기본값을 쓰고, part가 너무 많으면 키웁니다.
    target_part_bytes: int = 128 * 1024 * 1024
    # final point part 하나에 넣을 최대 point row 수입니다.
    max_part_rows: int = 10_000_000
    # final part 하나에 넣을 최대 sample 수입니다. 0이면 sample 수로는 제한하지 않습니다.
    max_part_samples: int = 0
    # parquet compression입니다. 일반 사용은 "zstd", 디버깅/속도 확인은 "none"을 쓸 수 있습니다.
    compression: str = "zstd"
    # sample/feature metadata에서 external key로 사용할 column 이름입니다.
    sample_key_col: str = DEFAULT_SAMPLE_KEY_COL
    feature_key_col: str = DEFAULT_FEATURE_KEY_COL


@dataclass
class ArraySampleParquetPart:
    part_id: int
    path: str
    trace_index_path: str
    first_sample_id: int
    last_sample_id: int
    sample_count: int
    trace_count: int
    row_count: int
    byte_size: int
    trace_index_byte_size: int = 0

    def to_json(self) -> dict:
        return {
            "part_id": int(self.part_id),
            "path": str(self.path),
            "trace_index_path": str(self.trace_index_path),
            "first_sample_id": int(self.first_sample_id),
            "last_sample_id": int(self.last_sample_id),
            "sample_count": int(self.sample_count),
            "trace_count": int(self.trace_count),
            "row_count": int(self.row_count),
            "byte_size": int(self.byte_size),
            "trace_index_byte_size": int(self.trace_index_byte_size),
        }


@dataclass
class ArraySampleParquetManifest:
    sample_meta_path: str
    feature_meta_path: str
    n_samples: int
    n_features: int
    sample_parts_path: str
    trace_index_parts_path: str
    parts: list[ArraySampleParquetPart]
    point_schema: list[PointColumnSpec]
    sample_key_col: str = DEFAULT_SAMPLE_KEY_COL
    feature_key_col: str = DEFAULT_FEATURE_KEY_COL
    id_scheme: str = "dense_row_ids"
    version: int = FORMAT_VERSION

    def to_json(self) -> dict:
        return {
            "format": FORMAT_NAME,
            "version": int(self.version),
            "id_scheme": self.id_scheme,
            "sample_meta_path": str(self.sample_meta_path),
            "feature_meta_path": str(self.feature_meta_path),
            "n_samples": int(self.n_samples),
            "n_features": int(self.n_features),
            "sample_parts_path": str(self.sample_parts_path),
            "trace_index_parts_path": str(self.trace_index_parts_path),
            "sample_key_col": str(self.sample_key_col),
            "feature_key_col": str(self.feature_key_col),
            "point_schema": [spec.to_json() for spec in self.point_schema],
            "parts": [part.to_json() for part in self.parts],
        }


def _relative_to(manifest_path: str, target_path: str) -> str:
    if not target_path:
        return ""
    target = Path(target_path)
    if not target.is_absolute():
        return str(target).replace("\\", "/")
    manifest_dir = Path(manifest_path).expanduser().resolve().parent
    return os.path.relpath(str(target.resolve()), str(manifest_dir)).replace("\\", "/")


def _resolve_against(manifest_path: str, stored_path: str) -> str:
    if not stored_path:
        return ""
    stored = Path(stored_path)
    if stored.is_absolute():
        return str(stored.resolve())
    return str((Path(manifest_path).expanduser().resolve().parent / stored).resolve())


def write_array_sample_parquet_manifest(path: str, manifest: ArraySampleParquetManifest):
    """manifest 내부 경로를 artifact-relative path로 정규화해서 저장합니다."""

    payload = manifest.to_json()
    payload["sample_meta_path"] = _relative_to(path, manifest.sample_meta_path)
    payload["feature_meta_path"] = _relative_to(path, manifest.feature_meta_path)
    payload["sample_parts_path"] = _relative_to(path, manifest.sample_parts_path)
    payload["trace_index_parts_path"] = _relative_to(path, manifest.trace_index_parts_path)
    for part in payload["parts"]:
        part["path"] = _relative_to(path, part["path"])
        part["trace_index_path"] = _relative_to(path, part["trace_index_path"])
    payload["point_schema"] = [spec.to_json() for spec in manifest.point_schema]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


def load_array_sample_parquet_manifest(path: str) -> ArraySampleParquetManifest:
    """array_sample_parquet manifest JSON을 읽고 모든 path를 절대경로로 해석합니다."""

    manifest_path = str(Path(path).expanduser().resolve())
    with open(manifest_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if data.get("format") != FORMAT_NAME:
        raise ValueError(f"unsupported array sample parquet format: {data.get('format')!r}")
    version = int(data.get("version", 0))
    if version != FORMAT_VERSION:
        raise ValueError(f"unsupported array sample parquet version: {version}")
    point_schema_payload = [dict(item) for item in data.get("point_schema") or []]
    return ArraySampleParquetManifest(
        sample_meta_path=_resolve_against(manifest_path, data["sample_meta_path"]),
        feature_meta_path=_resolve_against(manifest_path, data["feature_meta_path"]),
        n_samples=int(data["n_samples"]),
        n_features=int(data["n_features"]),
        sample_parts_path=_resolve_against(manifest_path, data["sample_parts_path"]),
        trace_index_parts_path=_resolve_against(manifest_path, data["trace_index_parts_path"]),
        parts=[
            ArraySampleParquetPart(
                part_id=int(item["part_id"]),
                path=_resolve_against(manifest_path, item["path"]),
                trace_index_path=_resolve_against(manifest_path, item["trace_index_path"]),
                first_sample_id=int(item["first_sample_id"]),
                last_sample_id=int(item["last_sample_id"]),
                sample_count=int(item["sample_count"]),
                trace_count=int(item["trace_count"]),
                row_count=int(item["row_count"]),
                byte_size=int(item["byte_size"]),
                trace_index_byte_size=int(item.get("trace_index_byte_size", 0)),
            )
            for item in data.get("parts") or []
        ],
        point_schema=_normalize_point_schema(point_schema_payload),
        sample_key_col=str(data.get("sample_key_col", DEFAULT_SAMPLE_KEY_COL)),
        feature_key_col=str(data.get("feature_key_col", DEFAULT_FEATURE_KEY_COL)),
        id_scheme=str(data.get("id_scheme", "dense_row_ids")),
        version=version,
    )
